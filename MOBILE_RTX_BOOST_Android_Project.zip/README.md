# MOBILE RTX BOOST — Android prototype

A native Android Kotlin + Jetpack Compose starter project with a dark/green gaming dashboard.

## What works in this prototype
- Native Android application UI.
- Reads manufacturer/model and Android version.
- Reads battery percentage and battery temperature when the device exposes it.
- Interactive local graphics preset selection (Power Save / Balanced / Quality).
- Device check explanation and visual-feature roadmap.

## Important technical limits
This app does **not** implement NVIDIA DLSS, frame generation, or universal game-level graphics changes. Android apps generally cannot inject a graphics pipeline into unrelated games or force a global FPS/resolution change. Actual upscaling requires image input/output access or integration into the game/rendering pipeline. FPS/GPU telemetry may require vendor-specific APIs or privileged access.

## Build APK
1. Install Android Studio (recent stable version) and Android SDK Platform 35.
2. Open this folder as a project.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK path, usually `app/build/outputs/apk/debug/app-debug.apk`.

If Gradle reports a plugin or SDK mismatch, update Android Studio/Gradle plugin and install the requested SDK platform.
