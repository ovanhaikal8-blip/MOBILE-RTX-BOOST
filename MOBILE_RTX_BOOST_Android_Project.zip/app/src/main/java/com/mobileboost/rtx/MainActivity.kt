package com.mobileboost.rtx

import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B09)
private val Panel = Color(0xFF121914)
private val Green = Color(0xFF76FF03)
private val Muted = Color(0xFF9BA79D)
private val White = Color(0xFFF2F7F3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Green, background = Bg, surface = Panel,
                onPrimary = Color.Black, onBackground = White, onSurface = White
            )) {
                BoostHome(this)
            }
        }
    }
}

@Composable
private fun BoostHome(context: Context) {
    var preset by remember { mutableStateOf("BALANCED") }
    var selectedTab by remember { mutableStateOf("HOME") }
    var scanMessage by remember { mutableStateOf("Device check belum dijalankan.") }
    val batteryManager = remember { context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager }
    val batteryPct = remember {
        batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    }
    val tempC = remember {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val raw = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        if (raw > 0) String.format("%.1f°C", raw / 10f) else "Tidak tersedia"
    }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(42.dp).background(Green, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Bolt, null, tint = Color.Black, modifier = Modifier.size(28.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("MOBILE RTX", fontSize = 20.sp, fontWeight = FontWeight.Black, color = White)
                Text("BOOST  /  GRAPHICS COMPANION", fontSize = 10.sp, color = Green, letterSpacing = 1.2.sp)
            }
            Text("v1.0", color = Muted, fontSize = 12.sp)
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("YOUR GAME.", color = White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
            Text("YOUR PERFORMANCE.", color = Green, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("Control center untuk pengalaman gaming mobile.", color = Muted, fontSize = 14.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("BATTERY", "$batteryPct%", "Level saat ini", Modifier.weight(1f))
            MetricCard("BATTERY TEMP", tempC, "Sensor perangkat", Modifier.weight(1f))
        }

        SectionTitle("GRAPHICS PRESET", "Pilih profil sesuai kebutuhan")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PresetRow("POWER SAVE", "Kurangi beban dan prioritaskan efisiensi", preset == "POWER SAVE") { preset = "POWER SAVE" }
            PresetRow("BALANCED", "Pilihan seimbang untuk penggunaan harian", preset == "BALANCED") { preset = "BALANCED" }
            PresetRow("QUALITY", "Prioritaskan kualitas pada game yang mendukung", preset == "QUALITY") { preset = "QUALITY" }
        }
        Text("Preset ini menyimpan pilihan di aplikasi. Android tidak mengizinkan aplikasi pihak ketiga mengubah grafis atau FPS semua game secara universal.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)

        SectionTitle("DEVICE CHECK", "Informasi dasar perangkat")
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoRow("MODEL", "${Build.MANUFACTURER} ${Build.MODEL}")
            InfoRow("ANDROID", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            InfoRow("PRESET AKTIF", preset)
            Button(
                onClick = {
                    scanMessage = "Pemeriksaan selesai. Model, versi Android, dan sensor baterai dibaca. FPS/GPU game tidak dapat diukur secara universal dari aplikasi ini."
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.Memory, null)
                Spacer(Modifier.width(8.dp))
                Text("CHECK DEVICE", fontWeight = FontWeight.Bold)
            }
            Text(scanMessage, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
        }

        SectionTitle("VISUAL LAB", "Roadmap fitur")
        FeatureRow(Icons.Default.Visibility, "AI Image Enhancement", "Peningkatan gambar statis dapat ditambahkan sebagai modul pemrosesan gambar.")
        FeatureRow(Icons.Default.Tune, "Game-specific tuning", "Dukungan lebih dalam membutuhkan integrasi per game atau dukungan sistem.")
        FeatureRow(Icons.Default.PhoneAndroid, "Compatibility", "Fitur bergantung pada versi Android, chipset, dan izin yang tersedia.")

        Text("Catatan: MOBILE RTX BOOST bukan produk NVIDIA dan tidak menjalankan DLSS. Ini adalah prototype independen yang terinspirasi dari dashboard gaming.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun MetricCard(label: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).border(1.dp, Color(0xFF26342A), RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Text(value, color = Green, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun PresetRow(title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(if (selected) Color(0xFF172719) else Panel, RoundedCornerShape(14.dp))
            .border(1.dp, if (selected) Green else Color(0xFF26342A), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = if (selected) Green else White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(description, color = Muted, fontSize = 11.sp)
        }
        RadioButton(selected = selected, onClick = onClick, colors = RadioButtonDefaults.colors(selectedColor = Green, unselectedColor = Muted))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(23.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(description, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}
